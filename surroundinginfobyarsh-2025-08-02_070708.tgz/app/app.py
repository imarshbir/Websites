from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

# In-memory storage for notices (replace with a database in a real application)
notices = {
    'national': [
        "National News 1: India launches Chandrayaan-3 moon mission.",
        "National News 2: India's GDP growth hits 7.8% in Q1 2023-24.",
    ],
    'international': [
        "International News 1: BRICS summit concludes in Johannesburg.",
        "International News 2: G20 nations discuss climate change challenges.",
    ],
    'notice': [
        "Notice 1: Independence Day celebration on August 15th.",
        "Notice 2: Online seminar on 'Digital India' initiative on August 20th.",
    ],
}

user_submissions = []

@app.route('/')
def index():
    """Renders the main page with news and notices."""
    return render_template('index.html', national_news=notices['national'], international_news=notices['international'], notices=notices['notice'], user_submissions=user_submissions)

@app.route('/publish', methods=['POST'])
def publish_notice():
    """Handles the submission of new notices."""
    title = request.form['notice-title']
    content = request.form['notice-content']
    notice_type = request.form['notice-type']

    if title and content:
        new_item = title + ":" + content
        notices[notice_type].append(new_item)
        user_submissions.append({'title': title, 'content': content, 'type': notice_type})
        return redirect(url_for('index') + '#my-submissions-list')  # Redirect to the main page and My Submissions section
    else:
        return "Please fill in both title and content!", 400

if __name__ == '__main__':
    app.run(debug=True)
    