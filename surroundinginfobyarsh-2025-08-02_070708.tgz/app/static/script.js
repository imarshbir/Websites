const nationalNewsList = document.getElementById('national-news-list');
const internationalNewsList = document.getElementById('international-news-list');
const noticesList = document.getElementById('notices-list');
const noticeForm = document.getElementById('notice-form');
const messageBox = document.getElementById('message-box');
const mySubmissionsList = document.getElementById('my-submissions-list');

let userSubmissions = [];

const initialNews = {
    national: [
        "National News 1: India launches Chandrayaan-3 moon mission.",
        "National News 2: India's GDP growth hits 7.8% in Q1 2023-24.",
    ],
    international: [
        "International News 1: BRICS summit concludes in Johannesburg.",
        "International News 2: G20 nations discuss climate change challenges.",
    ],
    notices: [
        "Notice 1: Independence Day celebration on August 15th.",
        "Notice 2: Online seminar on 'Digital India' initiative on August 20th.",
    ],
};

function displayNews() {
    nationalNewsList.innerHTML = initialNews.national
        .map((item) => `<li class="bg-blue-50 rounded-md p-3 text-blue-800">${item}</li>`)
        .join('');

    internationalNewsList.innerHTML = initialNews.international
        .map((item) => `<li class="bg-green-50 rounded-md p-3 text-green-800">${item}</li>`)
        .join('');

    noticesList.innerHTML = initialNews.notices
        .map((item) => `<li class="bg-purple-50 rounded-md p-3 text-purple-800">${item}</li>`)
        .join('');
}

function showMessage(message, type = 'success') {
    messageBox.textContent = message;
    messageBox.className = `fixed top-4 left-1/2 transform -translate-x-1/2 bg-${type === 'success' ? 'green' : 'red'}-100 text-${type === 'success' ? 'green' : 'red'}-700 border border-${type === 'success' ? 'green' : 'red'}-400 px-4 py-2 rounded shadow-md`;
    messageBox.classList.add('show');
    setTimeout(() => {
        messageBox.classList.remove('show');
    }, 3000);
}

function displayUserSubmissions() {
    mySubmissionsList.innerHTML = userSubmissions
        .map(
            (submission) => `<li class="bg-teal-50 rounded-md p-3 text-teal-800">
                <h4 class="font-semibold">${submission.title}</h4>
                <p class="text-sm">${submission.content}</p>
                <p class="text-xs italic">Type: ${submission.type}</p>
            </li>`
        )
        .join('');
}

noticeForm.addEventListener('submit', (event) => {
    event.preventDefault();

    const title = document.getElementById('notice-title').value;
    const content = document.getElementById('notice-content').value;
    const type = document.getElementById('notice-type').value;

    if (title && content) {
        const newItem = `${title}: ${content}`;
        switch (type) {
            case 'national':
                initialNews.national.push(newItem);
                nationalNewsList.innerHTML += `<li class="bg-blue-50 rounded-md p-3 text-blue-800">${newItem}</li>`;
                break;
            case 'international':
                initialNews.international.push(newItem);
                internationalNewsList.innerHTML += `<li class="bg-green-50 rounded-md p-3 text-green-800">${newItem}</li>`;
                break;
            case 'notice':
                initialNews.notices.push(newItem);
                noticesList.innerHTML += `<li class="bg-purple-50 rounded-md p-3 text-purple-800">${newItem}</li>`;
                break;
        }
        userSubmissions.push({ title, content, type });
        displayUserSubmissions();
        noticeForm.reset();
        showMessage('Your notice has been published successfully!', 'success');
    } else {
        showMessage('Please fill in both title and content!', 'error');
    }
});

displayNews();
displayUserSubmissions();